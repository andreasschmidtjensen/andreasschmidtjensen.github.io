package eisbw.percepts;

import eis.iilang.Percept;

public class GameStartPercept extends Percept {

    public GameStartPercept() {
        super(Percepts.GameStart);
    }
}

package eisbw.percepts;

import eis.iilang.Percept;

public class StimPercept extends Percept {

    public StimPercept() {
        super(Percepts.Stimmed);
    }
}

package eisbw.percepts.perceivers;

import eis.iilang.Percept;
import java.util.List;

public interface IPerceiver {
    public List<Percept> perceive();
}

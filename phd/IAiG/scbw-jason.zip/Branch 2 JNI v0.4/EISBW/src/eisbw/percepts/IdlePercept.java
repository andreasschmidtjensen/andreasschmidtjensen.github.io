package eisbw.percepts;

import eis.iilang.Percept;

public class IdlePercept extends Percept {

    public IdlePercept() {
        super(Percepts.Idle);
    }
}

package eisbw.percepts;

public class Identifiers {

    public static final String Vespene = "vespene";
    public static final String Mineral = "mineral";
}

package eisbw.percepts;

import eis.iilang.Percept;

public class ConstructingPercept extends Percept {

    public ConstructingPercept() {
        super(Percepts.Constructing);
    }
}

package jason.eis;

import eis.*;
import eis.exceptions.*;
import eis.iilang.*;
import jason.JasonException;
import jason.asSyntax.*;
import jason.asSyntax.parser.ParseException;
import jason.environment.Environment;
import jason.infra.centralised.*;
import jason.mas2j.AgentParameters;
import java.io.*;
import java.lang.reflect.Field;
import java.util.*;
import java.util.logging.*;

public class EISAdapter extends Environment {

    private static final Logger logger = Logger.getLogger(EISAdapter.class.getName());

    private EnvironmentInterfaceStandard ei;

    public EISAdapter() {
        super(20);
    }

    @Override
    public void init(String[] args) {
        if (args.length == 0) {
            logger.warning("The jar file with the EIS environment have to be informed as parameter!");
            return;
        }
        try {
            this.ei = EILoader.fromJarFile(new File(args[0]));

            Field privateStringField = CentralisedRuntimeServices.class.getDeclaredField("masRunner");
            privateStringField.setAccessible(true);
            RunCentralisedMAS runner = (RunCentralisedMAS) privateStringField.get((CentralisedRuntimeServices) getEnvironmentInfraTier().getRuntimeServices());
            AgentListener agentListener = new JasonAgentListener(this);
            EnvironmentListener listener = new JasonEnvironmentListener(ei, getEnvironmentInfraTier().getRuntimeServices(), 
                    agentListener, 
                    runner.getProject().getAgents(), 
                    runner.isDebug(), 
                    runner.getProject().getControlClass() != null);
            
            this.ei.attachEnvironmentListener(listener);
            
            Map initMapArgs = new HashMap();
            List<Structure> agentEntities = new ArrayList<>();

            for (int i = 1; i < args.length; i++) {
                Term t = ASSyntax.parseTerm(args[i]);
                if (t.isStructure()) {
                    Structure arg = (Structure) t;
                    switch (arg.getFunctor()) {
                        case "agent_entity":
                            agentEntities.add(arg);
                            break;
                        case "map":
                            initMapArgs.put(arg.getTerm(0).toString(), Translator.termToParameter(arg.getTerm(1)));
                            break;
                    }
                }
            }

            if (this.ei.isInitSupported()) {
                this.ei.init(initMapArgs);
            }

            try {
                if (this.ei.getState() != EnvironmentState.PAUSED) {
                    this.ei.pause();
                }
            } catch (ManagementException e) {
                e.printStackTrace();
            }

            if (this.ei.isStartSupported()) {
                this.ei.start();
            }
        } catch (IOException | ParseException | ManagementException | NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }

    public void handlePercept(String agent, Collection<Percept> percepts) {
        try {
            clearPercepts(agent);
            Literal[] jasonPers = new Literal[percepts.size()];
            int i = 0;
            for (Percept p : percepts) {
                jasonPers[(i++)] = Translator.perceptToLiteral(p);
            }
            addPercept(agent, jasonPers);
            informAgsEnvironmentChanged(new String[]{agent});
        } catch (JasonException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Literal> getPercepts(String agName) {
        if (ei.getAgents().contains(agName)) {
            return addEISPercept(super.getPercepts(agName), agName);
        } else {
            return super.getPercepts(agName);
        }
    }

    protected List<Literal> addEISPercept(List<Literal> percepts, String agName) {
        clearPercepts(agName);
        if (percepts == null) {
            percepts = new ArrayList();
        }
        Map<String, Collection<Percept>> perMap;
        Structure strcEnt;
        if (this.ei != null) {
            try {
                perMap = this.ei.getAllPercepts(agName, new String[0]);
                for (String entity : perMap.keySet()) {
                    strcEnt = ASSyntax.createStructure("entity", new Term[]{ASSyntax.createAtom(entity)});
                    for (Percept p : perMap.get(entity)) {
                        percepts.add(Translator.perceptToLiteral(p).addAnnots(new Term[]{strcEnt}));
                    }
                }
            } catch (PerceiveException | NoEnvironmentException | JasonException | NullPointerException e) {
                e.printStackTrace();
            }
        }
        return percepts;
    }

    @Override
    public boolean executeAction(String agName, Structure action) {
        if (this.ei == null) {
            logger.log(Level.WARNING, "There is no environment loaded! Ignoring action {0}", action);
            return false;
        }
        try {
            if ((action.getArity() == 2) && (action.getFunctor().equals("ae")) && (action.getTerm(1).isString())) {
                String entity = ((StringTerm) action.getTerm(1)).getString();

                this.ei.performAction(agName, Translator.literalToAction((Literal) action.getTerm(0)), new String[]{entity});
            } else {
                this.ei.performAction(agName, Translator.literalToAction(action), new String[0]);
            }

            return true;
        } catch (ActException e) {
            logger.log(Level.WARNING, String.format("Error in action ''%1$s'' by %2$s: %3$s", new Object[]{action, agName, e}));
        }
        return false;
    }

    @Override
    public void stop() {
        if (this.ei != null) {
            try {
                if (this.ei.isKillSupported()) {
                    this.ei.kill();
                }
            } catch (ManagementException e) {
                e.printStackTrace();
            }
        }
        super.stop();
    }
}

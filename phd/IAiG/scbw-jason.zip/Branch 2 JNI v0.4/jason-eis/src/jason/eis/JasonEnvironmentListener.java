package jason.eis;

import eis.*;
import eis.iilang.*;
import jason.mas2j.*;
import jason.runtime.RuntimeServicesInfraTier;
import java.util.*;
import java.util.logging.*;

public class JasonEnvironmentListener implements EnvironmentListener {

    private static final Logger logger = Logger.getLogger("EISAdapter." + EISAdapter.class.getName());
    private final EnvironmentInterfaceStandard eis;
    private final RuntimeServicesInfraTier runtimeServices;
    private final AgentListener agentListener;
    private final List<AgentParameters> agentParameters;
    private final boolean isDebug;
    private final boolean forceSync;

    public JasonEnvironmentListener(EnvironmentInterfaceStandard eis, RuntimeServicesInfraTier runtimeServices, AgentListener agentListener, List<AgentParameters> agentParameters, boolean isDebug, boolean forceSync) {
        this.eis = eis;
        this.runtimeServices = runtimeServices;
        this.agentListener = agentListener;
        this.agentParameters = agentParameters;
        this.isDebug = isDebug;
        this.forceSync = forceSync;
    }

    @Override
    public void handleStateChange(EnvironmentState newState) {
        logger.log(Level.WARNING, "State has changed to: " + newState.name());
    }

    @Override
    public void handleFreeEntity(String entity, Collection<String> agents) {
        logger.log(Level.WARNING, entity + " has been freed?");
    } 

    @Override
    public void handleDeletedEntity(String entity, Collection<String> agents) {
        runtimeServices.killAgent(entity, entity);
    }

    @Override
    public void handleNewEntity(String entity) {
        try {
            for (AgentParameters ap : this.agentParameters) {
                String unNumbered = entity.replaceAll("[0-9]+$", "");
                if (ap.getAgName().equalsIgnoreCase(entity) || ap.getAgName().equalsIgnoreCase(unNumbered)) {
                    
                    String agName = runtimeServices.createAgent(entity, ap.asSource.toString(), ap.agClass.getClassName(), ap.getAgArchClasses(), ap.getBBClass(), ap.getAsSetts(this.isDebug, this.forceSync));

                    eis.registerAgent(agName);
                    eis.attachAgentListener(agName, agentListener);
                    eis.associateEntity(agName, entity);

                    runtimeServices.startAgent(agName);
                    break;
                }
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Could not add " + entity, ex);
        }
    }
}

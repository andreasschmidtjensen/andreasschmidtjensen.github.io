package jason.eis;

import eis.*;
import eis.iilang.*;
import jason.*;
import jason.asSyntax.*;
import jason.environment.Environment;

public class JasonAgentListener implements AgentListener {
    private final Environment environment;

    public JasonAgentListener(Environment environment) {
        this.environment = environment;
    }
    
    @Override
    public void handlePercept(String agent, Percept percept) {
        try {
            environment.addPercept(agent, new Literal[]{Translator.perceptToLiteral(percept)});
        } catch (JasonException e) {
            e.printStackTrace();
        }
        environment.informAgsEnvironmentChanged(new String[]{agent});
    }

}

package jason.eis;

import eis.iilang.*;
import jason.*;
import jason.asSyntax.*;
import jason.asSyntax.parser.ParseException;
import java.util.*;

public class Translator {

    public static Literal perceptToLiteral(Percept per)
            throws JasonException {
        Literal l = ASSyntax.createLiteral(per.getName(), new Term[0]);
        for (Parameter par : per.getParameters()) {
            l.addTerm(parameterToTerm(par));
        }
        return l;
    }

//	public static Percept literalToPercept(Literal l) {
//		Percept p = new Percept(l.getFunctor());
//		for (Term t : l.getTerms()) {
//			p.addParameter(termToParameter(t));
//		}
//		return p;
//	}
    public static Action literalToAction(Literal action) {
        Parameter[] pars = new Parameter[action.getArity()];
        for (int i = 0; i < action.getArity(); i++) {
            pars[i] = termToParameter(action.getTerm(i));
        }
        return new Action(action.getFunctor(), pars);
    }

//	public static Structure actoinToStructure(Action action) throws JasonException {
//		Structure s = ASSyntax.createStructure(action.getName(), new Term[0]);
//		for (Parameter par : action.getParameters()) {
//			s.addTerm(parameterToTerm(par));
//		}
//		return s;
//	}
    public static Parameter termToParameter(Term t) {
        if (t.isNumeric()) {
            try {
                return new Numeral(Double.valueOf(((NumberTerm) t).solve()));
            } catch (NoValueForVarException ex) {
                System.out.println(ex);
                return new Numeral(0);
            }
        }
        if (t.isList()) {
            Collection terms = new ArrayList();
            for (Term listTerm : (ListTerm) t) {
                terms.add(termToParameter(listTerm));
            }
            return new ParameterList(terms);
        }
        if (t.isString()) {
            return new Identifier(((StringTerm) t).getString());
        }
        if (t.isLiteral()) {
            Literal l = (Literal) t;
            if (!l.hasTerm()) {
                return new Identifier(l.getFunctor());
            }
            Parameter[] terms = new Parameter[l.getArity()];
            for (int i = 0; i < l.getArity(); i++) {
                terms[i] = termToParameter(l.getTerm(i));
            }
            return new Function(l.getFunctor(), terms);
        }

        return new Identifier(t.toString());
    }

    public static Term parameterToTerm(Parameter par) throws JasonException {
        if ((par instanceof Numeral)) {
            return ASSyntax.createNumber(((Numeral) par).getValue().doubleValue());
        }
        if ((par instanceof Identifier)) {
            try {
                Identifier i = (Identifier) par;
                String a = i.getValue();
                if (!Character.isUpperCase(a.charAt(0))) {
                    return ASSyntax.parseTerm(a);
                }
            } catch (ParseException e) {
            }
            return ASSyntax.createString(((Identifier) par).getValue());
        }
        if ((par instanceof ParameterList)) {
            ListTerm list = new ListTermImpl();
            ListTerm tail = list;
            for (Parameter p : (ParameterList) par) {
                tail = tail.append(parameterToTerm(p));
            }
            return list;
        }
        if ((par instanceof Function)) {
            Function f = (Function) par;
            Structure l = ASSyntax.createStructure(f.getName(), new Term[0]);
            for (Parameter p : f.getParameters()) {
                l.addTerm(parameterToTerm(p));
            }
            return l;
        }
        if (par instanceof TruthValue) {
            TruthValue t = (TruthValue) par;
            return new Atom(t.getValue());
        }
        throw new JasonException("The type of parameter " + par + " is unknown!");
    }
}

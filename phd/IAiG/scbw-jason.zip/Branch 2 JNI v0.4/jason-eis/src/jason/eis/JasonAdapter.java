//package jason.eis;
//
//import eis.EIDefaultImpl;
//import eis.exceptions.ActException;
//import eis.exceptions.ManagementException;
//import eis.exceptions.NoEnvironmentException;
//import eis.exceptions.PerceiveException;
//import eis.iilang.Action;
//import eis.iilang.EnvironmentState;
//import eis.iilang.Parameter;
//import eis.iilang.Percept;
//import jason.JasonException;
//import jason.asSyntax.Literal;
//import jason.environment.Environment;
//import java.util.HashMap;
//import java.util.LinkedList;
//import java.util.List;
//import java.util.Map;
//
//public abstract class JasonAdapter extends EIDefaultImpl {
//
//	protected Environment jasonEnv = null;
//	private Map<String, List<Literal>> previousPerception = new HashMap();
//
//	@Override
//	public void init(Map<String, Parameter> parameters)
//			throws ManagementException {
//		super.init(parameters);
//		String[] args = new String[parameters.size()];
//		int i = 0;
//		for (Parameter p : parameters.values()) {
//			args[(i++)] = p.toProlog();
//		}
//		this.jasonEnv.init(args);
//		setState(EnvironmentState.PAUSED);
//	}
//
//	@Override
//	public void kill() throws ManagementException {
//		super.kill();
//		this.jasonEnv.stop();
//	}
//
//	@Override
//	protected LinkedList<Percept> getAllPerceptsFromEntity(String ent)
//			throws PerceiveException, NoEnvironmentException {
//		LinkedList eisPer = new LinkedList();
//		List<Literal> lper = this.jasonEnv.getPercepts(ent);
//		if (lper == null) {
//			lper = (List) this.previousPerception.get(ent);
//		} else {
//			lper = (List) this.previousPerception.put(ent, lper);
//		}
//		if (lper != null) {
//			for (Literal jasonPer : lper) {
//				eisPer.add(Translator.literalToPercept(jasonPer));
//			}
//		}
//		return eisPer;
//	}
//
//	@Override
//	protected Percept performEntityAction(String agent, Action action) throws ActException {
//		try {
//			boolean ok = this.jasonEnv.executeAction(agent, Translator.actoinToStructure(action));
//			if (!ok) {
//				throw new ActException(7, "error executing action " + action.toProlog());
//			}
//		} catch (JasonException e) {
//			e.printStackTrace();
//			throw new ActException(7, e.getMessage());
//		}
//		return null;
//	}
//
//	@Override
//	public String requiredVersion() {
//		return "0.3";
//	}
//}

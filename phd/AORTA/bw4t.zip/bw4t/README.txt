First Responders scenario in Jason+AORTA
========================================
Requirements:
- Java 7
- Blocks World for Teams (BW4T) server

The map files from bw4tmaps/ should be copied into <BW4T server location>/maps. Run the BW4T server and select a firstresponders map.

The agents can then be run using the command "ant run".